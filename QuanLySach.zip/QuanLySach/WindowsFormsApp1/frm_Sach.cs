﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frm_Sach : Form
    {
        LOPDUNGCHUNG lopchung = new LOPDUNGCHUNG();
        public frm_Sach()
        {
            InitializeComponent();
        }
        public void LoadSach()
        {
            string sql = "Select * from SACH";
            dt_Sach.DataSource = lopchung.LoadDL(sql);
        }
        public void LoadTheLoai()
        {
            string sql = "Select * from THELOAI";
            cb_TheLoai.DataSource = lopchung.LoadDL(sql);
            cb_TheLoai.DisplayMember = "TENTHELOAI";
            cb_TheLoai.ValueMember = "MATHELOAI";
        }

        private void frm_Sach_Load(object sender, EventArgs e)
        {
            LoadSach();
            LoadTheLoai();
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            string sql = "Insert into SACH values ('" + txt_MaSach.Text + "','" + cb_TheLoai.SelectedValue + "','" + txt_TenSach.Text + "',Convert(datetime,'" + dt_NgayXuatBan.Text + "',103),'" + txt_TomTat.Text + "')";
            int kq = lopchung.ThemXoaSua(sql);
            if (kq >= 1) MessageBox.Show("Thêm sách thành công");
            else MessageBox.Show("Thêm sách thất bại");
            LoadSach();
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            string sql = "Delete SACH where MASACH ='" + txt_MaSach.Text + "'";
            int kq = lopchung.ThemXoaSua(sql);
            if (kq >= 1) MessageBox.Show("Xóa sách thành công");
            else MessageBox.Show("Xóa sách thất bại");
            LoadSach();
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            string sql = "Update SACH set MATHELOAI = '" + cb_TheLoai.SelectedValue + "',TENSACH = '" + txt_TenSach.Text + "',NGAYXUATBAN = Convert(datetime,'" + dt_NgayXuatBan.Text + "',103),TOMTAT = '" + txt_TomTat.Text + "' where MASACH ='" + txt_MaSach.Text + "'";
            int kq = lopchung.ThemXoaSua(sql);
            if (kq >= 1) MessageBox.Show("Cập nhật sách thành công");
            else MessageBox.Show("Cập nhật sách thất bại");
            LoadSach();
        }

        private void dt_Sach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_MaSach.Text = dt_Sach.CurrentRow.Cells["MASACH"].Value.ToString();
            txt_TenSach.Text = dt_Sach.CurrentRow.Cells["TENSACH"].Value.ToString();
            txt_TomTat.Text = dt_Sach.CurrentRow.Cells["TOMTAT"].Value.ToString();
            cb_TheLoai.SelectedValue = dt_Sach.CurrentRow.Cells["MATHELOAI"].Value.ToString();
            dt_NgayXuatBan.Text = dt_Sach.CurrentRow.Cells["NGAYXUATBAN"].Value.ToString();

        }
    }
}